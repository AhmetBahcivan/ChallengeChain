import React, { useState } from 'react';

const AddReflection = ({ onAddReflection }) => {
    const [question, setQuestion] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (question.trim()) {
            onAddReflection(question.trim());
            setQuestion('');
        }
    };

    return (
        <form onSubmit={handleSubmit} className="mt-4">
            <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Add a new reflection question..."
                className="w-full p-2 border rounded"
            />
            <button
                type="submit"
                className="mt-2 bg-green-500 text-white px-4 py-2 rounded"
            >
                Add Reflection
            </button>
        </form>
    );
};

export default AddReflection;