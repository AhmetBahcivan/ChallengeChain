import React, {useEffect, useState} from 'react'
import { PlayIcon, PauseIcon, VolumeOffIcon } from 'lucide-react'
import {useNavigate, useParams} from "react-router-dom";
import {auth} from "./firebaseConfig";
import {fetchVideo} from "./firebaseFunctions";

export default function WatchSection() {
    const [isPlaying, setIsPlaying] = useState(false)
    const [isMuted, setIsMuted] = useState(false)
    const [showDescription, setShowDescription] = useState(false)
    const { videoId } = useParams();
    const navigate = useNavigate();
    const [currentStage, setCurrentStage] = useState('watch');
    const [video, setVideo] = useState(null);
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const togglePlay = () => setIsPlaying(!isPlaying)
    const toggleMute = () => setIsMuted(!isMuted)
    const toggleDescription = () => setShowDescription(!showDescription)

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((currentUser) => {
            setUser(currentUser);
        });

        return () => unsubscribe();
    }, []);

    useEffect(() => {
        const loadVideo = async () => {
            try {
                setLoading(true);
                const videoData = await fetchVideo(videoId);
                setVideo(videoData);
            } catch (err) {
                setError('Failed to load video. Please try again.');
                console.error('Error loading video:', err);
            } finally {
                setLoading(false);
            }
        };
        loadVideo();
    }, [videoId]);


    return (
        <div className="max-w-4xl mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">Hayat Dersleri: Watch</h1>

            {/* Video Player */}
            <div className="relative aspect-video bg-gray-200 mb-4">
                <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-gray-500">Video Player Placeholder</span>
                    <iframe
                        src={`https://www.youtube.com/embed/${videoId}`}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="absolute inset-0 w-full h-full"
                    ></iframe>
                </div>
            </div>

            {/* Video Information */}
            <div className="mb-4">
                <h2 className="text-xl font-semibold">Video Title</h2>
                <p className="text-sm text-gray-600">Channel Name • 1M views • 2 weeks ago</p>
            </div>

            {/* Description Toggle */}
            <button
                onClick={toggleDescription}
                className="mb-2 text-blue-600 hover:underline focus:outline-none"
            >
                {showDescription ? 'Hide Description' : 'Show Description'}
            </button>

            {/* Video Description */}
            {showDescription && (
                <div className="mb-4 p-4 bg-gray-100 rounded-md">
                    <p>This is the video description. It can contain multiple paragraphs and provide more information about the content of the video.</p>
                </div>
            )}

            {/* Navigate to Think Section */}
            <button className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-300">
                Move to Think Section
            </button>
        </div>
    )
}