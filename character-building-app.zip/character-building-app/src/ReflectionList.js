import React, { useState, useEffect } from 'react';
import { fetchReflections, addReflection, addAnswer, fetchAnswers } from './firebaseFunctions';

const ReflectionList = ({ videoId, userId }) => {
    const [reflections, setReflections] = useState([]);
    const [newQuestion, setNewQuestion] = useState('');
    const [answerTexts, setAnswerTexts] = useState({});
    const [openReflectionId, setOpenReflectionId] = useState(null);

    useEffect(() => {
        loadReflections();
    }, [videoId]);

    const loadReflections = async () => {
        const fetchedReflections = await fetchReflections(videoId);
        const reflectionsWithAnswers = await Promise.all(fetchedReflections.map(async (reflection) => {
            const answers = await fetchAnswers(reflection.id);
            return { ...reflection, answers };
        }));
        setReflections(reflectionsWithAnswers);
    };

    const handleAddQuestion = async (e) => {
        e.preventDefault();
        if (newQuestion.trim()) {
            await addReflection(videoId, newQuestion, userId);
            setNewQuestion('');
            loadReflections();
        }
    };

    const handleAddAnswer = async (reflectionId) => {
        const answerText = answerTexts[reflectionId];
        if (answerText && answerText.trim()) {
            await addAnswer(videoId, reflectionId, answerText, userId);
            setAnswerTexts(prev => ({ ...prev, [reflectionId]: '' }));
            loadReflections();
        }
    };

    const loadAnswers = async (reflectionId) => {

    }

    const toggleAccordion = (reflectionId) => {
        setOpenReflectionId(openReflectionId === reflectionId ? null : reflectionId);
    };

    return (
        <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">Reflection Questions</h2>
            <div className="mb-6">
                {reflections.map((reflection) => (
                    <div key={reflection.id} className="mb-4 border rounded">
                        <button
                            className="w-full text-left p-4 font-semibold bg-gray-100 hover:bg-gray-200 focus:outline-none"
                            onClick={() => toggleAccordion(reflection.id)}
                        >
                            {reflection.question}
                        </button>
                        {openReflectionId === reflection.id && (
                            <div className="p-4">
                                {reflection.answers.map((answer, index) => (
                                    <p key={index} className="mb-2 pl-4 border-l-2 border-gray-300">
                                        {answer.text}
                                    </p>
                                ))}
                                <form onSubmit={(e) => { e.preventDefault(); handleAddAnswer(reflection.id); }} className="mt-4">
                                    <input
                                        type="text"
                                        value={answerTexts[reflection.id] || ''}
                                        onChange={(e) => setAnswerTexts(prev => ({ ...prev, [reflection.id]: e.target.value }))}
                                        placeholder="Add your answer"
                                        className="w-full p-2 border rounded"
                                    />
                                    <button type="submit" className="mt-2 bg-green-500 text-white px-4 py-2 rounded">
                                        Submit Answer
                                    </button>
                                </form>
                            </div>
                        )}
                    </div>
                ))}
            </div>
            <form onSubmit={handleAddQuestion} className="mt-6">
                <input
                    type="text"
                    value={newQuestion}
                    onChange={(e) => setNewQuestion(e.target.value)}
                    placeholder="Add a new reflection question"
                    className="w-full p-2 border rounded"
                />
                <button type="submit" className="mt-2 bg-blue-500 text-white px-4 py-2 rounded">
                    Add Question
                </button>
            </form>
        </div>
    );
};

export default ReflectionList;