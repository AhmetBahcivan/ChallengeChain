import { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from './firebaseConfig';

export const useReflections = (videoId) => {
    const [reflections, setReflections] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const q = query(
            collection(db, 'Reflections'),
            where('videoId', '==', videoId),
            orderBy('createdAt', 'desc')
        );

        const unsubscribe = onSnapshot(q,
            (querySnapshot) => {
                const reflectionsData = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setReflections(reflectionsData);
                setLoading(false);
            },
            (err) => {
                console.error("Error fetching reflections: ", err);
                setError(err);
                setLoading(false);
            }
        );

        return () => unsubscribe();
    }, [videoId]);

    return { reflections, loading, error };
};