import React, { useState } from 'react'
import { PlusCircle, CheckCircle, XCircle } from 'lucide-react'

const suggestedChains = [
    { id: 1, name: "Daily Exercise", totalDays: 30, completedDays: 0, lastThreeDays: [false, false, false] },
    { id: 2, name: "Meditation", totalDays: 21, completedDays: 0, lastThreeDays: [false, false, false] },
    { id: 3, name: "Reading", totalDays: 14, completedDays: 0, lastThreeDays: [false, false, false] },
]

export default function ChainTracker() {
    const [assignedChains, setAssignedChains] = useState([])
    const [showModal, setShowModal] = useState(false)
    const [selectedChain, setSelectedChain] = useState(null)

    const assignChain = (chain) => {
        setAssignedChains([...assignedChains, { ...chain, completedDays: 0, lastThreeDays: [false, false, false] }])
    }

    const toggleDayCompletion = (chainId, day) => {
        setAssignedChains(chains =>
            chains.map(chain =>
                chain.id === chainId
                    ? {
                        ...chain,
                        completedDays: chain.completedDays + (chain.lastThreeDays[day] ? -1 : 1),
                        lastThreeDays: chain.lastThreeDays.map((d, i) => i === day ? !d : d)
                    }
                    : chain
            )
        )
    }

    return (
        <div className="min-h-screen bg-gray-100 p-4 sm:p-6 lg:p-8">
            <header className="mb-8 text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Chain Tracker</h1>
                <p className="text-gray-600">Build habits, one day at a time</p>
            </header>

            <div className="grid gap-8 md:grid-cols-2">
                <section className="bg-white rounded-lg shadow p-6">
                    <h2 className="text-xl font-semibold mb-4">Suggested Chains</h2>
                    <ul className="space-y-4">
                        {suggestedChains.map(chain => (
                            <li key={chain.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                                <span>{chain.name}</span>
                                <button
                                    onClick={() => {
                                        setSelectedChain(chain)
                                        setShowModal(true)
                                    }}
                                    className="text-blue-600 hover:text-blue-800"
                                >
                                    <PlusCircle className="w-6 h-6" />
                                </button>
                            </li>
                        ))}
                    </ul>
                </section>

                <section className="bg-white rounded-lg shadow p-6">
                    <h2 className="text-xl font-semibold mb-4">Your Chains</h2>
                    {assignedChains.length === 0 ? (
                        <p className="text-gray-600 text-center py-4">No chains assigned yet. Start by adding a suggested chain!</p>
                    ) : (
                        <ul className="space-y-6">
                            {assignedChains.map(chain => (
                                <li key={chain.id} className="bg-gray-50 rounded-md p-4">
                                    <div className="flex justify-between items-center mb-2">
                                        <h3 className="font-medium">{chain.name}</h3>
                                        <span className="text-sm text-gray-600">
                      {chain.completedDays} / {chain.totalDays} days
                    </span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                                        <div
                                            className="bg-blue-600 h-2.5 rounded-full"
                                            style={{ width: `${(chain.completedDays / chain.totalDays) * 100}%` }}
                                        ></div>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <div className="flex space-x-2">
                                            {chain.lastThreeDays.map((completed, index) => (
                                                <button
                                                    key={index}
                                                    onClick={() => toggleDayCompletion(chain.id, index)}
                                                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                                        completed ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                                                    }`}
                                                >
                                                    {completed ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                                                </button>
                                            ))}
                                        </div>
                                        <span className="text-sm text-gray-600">Last 3 days</span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </section>
            </div>

            {showModal && selectedChain && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg p-6 max-w-sm w-full">
                        <h3 className="text-lg font-semibold mb-2">{selectedChain.name}</h3>
                        <p className="text-gray-600 mb-4">Duration: {selectedChain.totalDays} days</p>
                        <div className="flex justify-end space-x-4">
                            <button
                                onClick={() => setShowModal(false)}
                                className="px-4 py-2 text-gray-600 hover:text-gray-800"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => {
                                    assignChain(selectedChain)
                                    setShowModal(false)
                                }}
                                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                            >
                                Assign Chain
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}