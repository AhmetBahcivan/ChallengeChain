import React, { useState, useEffect } from 'react';
import { fetchChains, joinChain, createChain } from './firebaseFunctions';
// Import icons from a library you're already using, or remove if not available
// import { PlusCircle, Play, Pause, ChevronDown, ChevronUp } from 'lucide-react';

// Custom Alert component
const Alert = ({ children, variant = 'info' }) => {
    const bgColor = variant === 'error' ? 'bg-red-100' : 'bg-blue-100';
    const textColor = variant === 'error' ? 'text-red-700' : 'text-blue-700';

    return (
        <div className={`${bgColor} ${textColor} p-4 rounded-md mb-4`} role="alert">
            {children}
        </div>
    );
};

const ChainList = ({ userId, videoId }) => {
    const [chains, setChains] = useState([]);
    const [newChainName, setNewChainName] = useState('');
    const [newChainMinDays, setNewChainMinDays] = useState(3);
    const [isCreateFormOpen, setIsCreateFormOpen] = useState(false);
    const [expandedChainId, setExpandedChainId] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        loadChains();
    }, [videoId, userId]);

    const loadChains = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const fetchedChains = await fetchChains(videoId, userId);
            setChains(fetchedChains);
        } catch (err) {
            console.error('Error fetching chains:', err);
            setError('Failed to load action chains. Please try again later.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCreateChain = async (e) => {
        e.preventDefault();
        if (newChainName.trim()) {
            const chainData = {
                chainName: newChainName.trim(),
                videoId: videoId,
                minDays: newChainMinDays,
                isGroupChain: false,
                completionRule: 'all',
            };

            try {
                await createChain(chainData, userId);
                setNewChainName('');
                setNewChainMinDays(3);
                setIsCreateFormOpen(false);
                loadChains();
            } catch (err) {
                console.error('Error creating chain:', err);
                setError('Failed to create the chain. Please try again.');
            }
        }
    };

    const handleStartChain = async (chainId) => {
        try {
            await joinChain(chainId, userId);
            loadChains();
        } catch (err) {
            console.error('Error joining chain:', err);
            setError('Failed to join the chain. Please try again.');
        }
    };

    const isChainStarted = (chain) => {
        return chain.progress && chain.progress.status === 'active';
    };

    const toggleCreateForm = () => setIsCreateFormOpen(!isCreateFormOpen);
    const toggleChainExpansion = (chainId) => {
        setExpandedChainId(expandedChainId === chainId ? null : chainId);
    };

    if (isLoading) {
        return <div className="text-center py-8">Loading action chains...</div>;
    }

    return (
        <div className="mt-8 max-w-3xl mx-auto">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Action Chains</h2>
                <button
                    onClick={toggleCreateForm}
                    className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
                >
                    {/* If you don't have icon components, you can use text instead */}
                    {/* <PlusCircle className="mr-2" size={20} /> */}
                    + Create New Chain
                </button>
            </div>

            {error && (
                <Alert variant="error">
                    <strong>Error: </strong>{error}
                </Alert>
            )}

            {isCreateFormOpen && (
                <form onSubmit={handleCreateChain} className="bg-white p-6 rounded-lg shadow-md mb-6">
                    <div className="mb-4">
                        <label htmlFor="chainName" className="block text-sm font-medium text-gray-700 mb-1">
                            Chain Name
                        </label>
                        <input
                            id="chainName"
                            type="text"
                            value={newChainName}
                            onChange={(e) => setNewChainName(e.target.value)}
                            placeholder="Enter chain name"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="minDays" className="block text-sm font-medium text-gray-700 mb-1">
                            Minimum Days
                        </label>
                        <input
                            id="minDays"
                            type="number"
                            value={newChainMinDays}
                            onChange={(e) => setNewChainMinDays(Number(e.target.value))}
                            min="1"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
                    >
                        Create Chain
                    </button>
                </form>
            )}

            {chains.length === 0 ? (
                <Alert>
                    <strong>No Action Chains</strong>
                    <p>You haven't created any action chains yet. Click the "Create New Chain" button to get started.</p>
                </Alert>
            ) : (
                <div className="space-y-4">
                    {chains.map((chain) => (
                        <div key={chain.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                            <div
                                className="p-4 flex justify-between items-center cursor-pointer hover:bg-gray-50"
                                onClick={() => toggleChainExpansion(chain.id)}
                            >
                                <div>
                                    <h3 className="font-bold text-lg">{chain.chainName}</h3>
                                    <p className="text-sm text-gray-600">Minimum days: {chain.minDays}</p>
                                </div>
                                <div className="flex items-center">
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handleStartChain(chain.id);
                                        }}
                                        disabled={isChainStarted(chain)}
                                        className={`mr-4 p-2 rounded-full ${
                                            isChainStarted(chain)
                                                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                                                : 'bg-green-100 text-green-600 hover:bg-green-200'
                                        }`}
                                    >
                                        {isChainStarted(chain) ? 'Pause' : 'Start'}
                                    </button>
                                    {expandedChainId === chain.id ? '▲' : '▼'}
                                </div>
                            </div>
                            {expandedChainId === chain.id && (
                                <div className="p-4 bg-gray-50 border-t border-gray-200">
                                    <p className="text-sm text-gray-700">
                                        This chain requires a minimum of {chain.minDays} days to complete.
                                        {isChainStarted(chain)
                                            ? " You've already started this chain. Keep up the good work!"
                                            : " Click the play button to start this chain."}
                                    </p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ChainList;